﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cviko9
{
    internal class Calculator
    {
        public string Memory { get; set; } = "";
        public string Display { get; set; } = "";

        private double number1 = 0;
        private double number2 = 0;
        private double result = 0;
        private double memory = 0;

        private enum State
        {
            FirstNum,
            SecondNum,
            Result
        };

        private enum Operation
        {
            Plus,
            Minus,
            Multi,
            Divide
        };
        private State _state = State.FirstNum;
        private Operation _oper;

        public void Tlacitko(string input)
        {
            double M;
            switch (input)
                {
                case "+":
                    Display = "";
                    _oper = Operation.Plus;
                    _state = State.SecondNum;
                    break;
               case "-":
                     Display = "";
                     _oper = Operation.Minus;
                    _state = State.SecondNum;
                    break;
                case "/":
                     Display = "";
                     _oper = Operation.Divide;
                    _state = State.SecondNum;
                    break;
                case "*":
                     Display = "";
                     _oper = Operation.Multi;
                    _state = State.SecondNum;
                    break;
                case "=":
                     Display = "";
                     _state = State.Result;
                     break;
                case "M+":
                    double.TryParse(Display, out M);
                    Memory = "M";
                    memory += M;
                    Display = memory.ToString();
                    break;
                case "M-":
                    double.TryParse(Display, out M);
                    Memory = "M";
                    memory -= M;
                    Display = memory.ToString();
                    break;
                case "MR":
                    Display = memory.ToString();
                    break;
                case "MS":
                    Memory = "M";
                    double.TryParse(Display, out memory);
                    Display = memory.ToString();
                    break;
                case "MC":
                    Memory = "";
                    memory = 0;
                    break;
                case "C":
                    Display = "";
                    _state = State.FirstNum;
                    break;
                default:
                    Display += input;
                    break;
            }
            Calculate();
        }
        public void Calculate()
        {
            if (_state == State.FirstNum)
            {
                    double.TryParse(Display, out number1);
                    return;
             }
             else if (_state == State.SecondNum)
             {
                    double.TryParse(Display, out number2);
                    return;
            }
            if (_state == State.Result) {
                switch (_oper)
                {
                    case Operation.Plus:
                        result = number1 + number2;

                        break;
                    case Operation.Minus:
                        result = number1 - number2;
  
                        break;
                    case Operation.Divide:
                        result = number1 / number2;

                        break;
                    case Operation.Multi:
                        result = number1 * number2;

                        break;
                }
                Display = result.ToString();
                number1 = result;
                _state = State.FirstNum;
            }
    }
}
}

